{
	id:3,
	name:"Test",
	frameRate:5,
	start:function(){
	    var test = this;
		App.getDataFromUrl("http://pv.sohu.com/cityjson?ie=utf-8",function(result){	
		    test.ip= JSON.parse(result.substring(19,result.length-2)).cip;
		    App.getDataFromUrl("https://tianqiapi.com/api?version=v6&appid=62129255&appsecret=w0E72XSR&ip="+test.ip,function(result){
		        var object = JSON.parse(result);
		        App.toast(object.tem)
		    });
		});
	},
	drawGui:function(canvas,paint){
	 
	},
	keyEvent:function(keyWord){
		
	},
	end:function(){
	}
}