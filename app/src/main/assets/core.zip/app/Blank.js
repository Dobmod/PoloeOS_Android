{
	id:2,
	name:"",
	start:function(){
		
	},
	drawGui:function(canvas,paint){
      
	},
	keyEvent:function(keyWord){
		
	},
	end:function(){
	}
}